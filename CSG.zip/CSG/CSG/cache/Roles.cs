﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSG.cache
{
    public struct Roles
    {
        public const string ADM = "ADM";
        public const string JTE = "JTE";
        public const string TEC = "TEC";
        public const string REC = "REC";
    }
}
