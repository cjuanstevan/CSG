﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSG.cache
{
    public static class UserCache
    {
        public static string UserCode { get; set; }
        public static string UserDefinition { get; set; }
        public static string UserAccount { get; set; }
        public static string UserPass { get; set; }
        public static string UserEmail { get; set; }
        public static string UserToken { get; set; }
        public static char UserUseToken { get; set; }
        public static string UserRol { get; set; }
        public static string UserRolDefinition { get; set; }
        
    }
}
